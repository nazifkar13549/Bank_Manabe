plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.manabe.bank"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.manabe.bank"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// عمداً هیچ کتابخانه خارجی استفاده نشده است؛ خواندن اکسل و تاریخ شمسی داخل خود پروژه نوشته شده.
dependencies {
}
