package ir.manabe.bank

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/** تبدیل تاریخ میلادی به شمسی و قالب‌بندی ساعت و تاریخ */
object Jalali {
    val MONTHS = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )
    val WEEKDAYS = arrayOf(
        "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"
    )

    /** خروجی: [سال، ماه، روز] شمسی */
    fun convert(gy: Int, gm: Int, gd: Int): IntArray {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) +
            ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + days / 31
            jd = 1 + days % 31
        } else {
            jm = 7 + (days - 186) / 30
            jd = 1 + (days - 186) % 30
        }
        return intArrayOf(jy, jm, jd)
    }

    private fun calendar(ms: Long, tz: TimeZone): Calendar =
        Calendar.getInstance(tz).apply { timeInMillis = ms }

    /** مثال: یکشنبه ۱ آذر ۱۴۰۵ */
    fun dateText(ms: Long, tz: TimeZone): String {
        val c = calendar(ms, tz)
        val j = convert(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        val wd = (c.get(Calendar.DAY_OF_WEEK) + 7 - Calendar.SATURDAY) % 7
        return Fa.digitsFa("${WEEKDAYS[wd]} ${j[2]} ${MONTHS[j[1] - 1]} ${j[0]}")
    }

    /** مثال: ۱۳:۵۱:۲۰ */
    fun timeText(ms: Long, tz: TimeZone): String {
        val c = calendar(ms, tz)
        return Fa.digitsFa(
            String.format(
                Locale.US, "%02d:%02d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND)
            )
        )
    }

    /** مثال: ۱۴۰۵/۰۹/۰۱ - ۱۳:۵۱ */
    fun shortDateTime(ms: Long, tz: TimeZone): String {
        val c = calendar(ms, tz)
        val j = convert(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return Fa.digitsFa(
            String.format(
                Locale.US, "%04d/%02d/%02d - %02d:%02d",
                j[0], j[1], j[2], c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)
            )
        )
    }
}
