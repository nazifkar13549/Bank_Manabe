package ir.manabe.bank

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.Switch
import android.widget.TextView
import java.util.Date

class SettingsActivity : Activity() {

    private lateinit var tvStats: TextView
    private lateinit var btnImport: Button
    private lateinit var btnClear: Button
    private lateinit var progress: ProgressBar
    private lateinit var rbReplace: RadioButton
    private lateinit var rbAppend: RadioButton
    private lateinit var swTehran: Switch

    private companion object {
        const val REQ_PICK = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        actionBar?.setDisplayHomeAsUpEnabled(true)

        tvStats = findViewById(R.id.tvStats)
        btnImport = findViewById(R.id.btnImport)
        btnClear = findViewById(R.id.btnClear)
        progress = findViewById(R.id.progress)
        rbReplace = findViewById(R.id.rbReplace)
        rbAppend = findViewById(R.id.rbAppend)
        swTehran = findViewById(R.id.swTehran)

        if (Prefs.replaceMode(this)) rbReplace.isChecked = true else rbAppend.isChecked = true
        rbReplace.setOnCheckedChangeListener { _, checked ->
            if (checked) Prefs.setReplaceMode(this, true)
        }
        rbAppend.setOnCheckedChangeListener { _, checked ->
            if (checked) Prefs.setReplaceMode(this, false)
        }

        swTehran.isChecked = Prefs.tehranTz(this)
        swTehran.setOnCheckedChangeListener { _, checked -> Prefs.setTehranTz(this, checked) }

        btnImport.setOnClickListener { pickFile() }
        btnClear.setOnClickListener { confirmClear() }

        refreshStats()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun refreshStats() {
        Thread {
            val db = Db(this)
            val rows = db.count()
            val companies = db.companyCount()
            runOnUiThread {
                val last = Prefs.lastUpdate(this)
                val lastText = if (last == 0L) "—"
                else Jalali.shortDateTime(last, Prefs.timeZone(this))
                val file = Prefs.lastFile(this)
                tvStats.text = "تعداد ردیف‌ها: ${Fa.digitsFa(rows)}\n" +
                    "تعداد شرکت‌ها: ${Fa.digitsFa(companies)}\n" +
                    "آخرین بروزرسانی: $lastText" +
                    (if (file.isNotEmpty()) "\nفایل: $file" else "")
            }
        }.start()
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "text/csv",
                    "text/comma-separated-values",
                    "application/csv",
                    "application/vnd.ms-excel",
                    "application/octet-stream",
                    "text/plain"
                )
            )
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            data?.data?.let { doImport(it) }
        }
    }

    private fun fileName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx) ?: ""
            }
        } catch (e: Exception) {
        }
        return ""
    }

    private fun setBusy(busy: Boolean) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        btnImport.isEnabled = !busy
        btnClear.isEnabled = !busy
    }

    private fun doImport(uri: Uri) {
        setBusy(true)
        val replace = Prefs.replaceMode(this)
        val name = fileName(uri)
        Thread {
            try {
                val res = Importer.parse(this, uri)
                if (res.rows.isEmpty()) {
                    throw IllegalArgumentException(
                        "هیچ ردیف معتبری پیدا نشد.\nمطمئن شوید ستون «نام شرکت» پر است و ردیف اول عنوان ستون‌هاست."
                    )
                }
                val db = Db(this)
                val msg = StringBuilder()
                if (replace) {
                    val n = db.replaceAll(res.rows)
                    msg.append("اطلاعات جایگزین شد.\nتعداد ردیف‌های ثبت‌شده: ${Fa.digitsFa(n)}")
                } else {
                    val (added, dup) = db.append(res.rows)
                    msg.append("اطلاعات جدید اضافه شد.\nردیف‌های جدید: ${Fa.digitsFa(added)}")
                    msg.append("\nردیف‌های تکراری (نادیده گرفته شد): ${Fa.digitsFa(dup)}")
                }
                if (res.skipped > 0) {
                    msg.append("\nردیف‌های بدون نام شرکت (ردشده): ${Fa.digitsFa(res.skipped)}")
                }
                if (!res.headerFound) {
                    msg.append("\n\nتوجه: عنوان ستون‌ها تشخیص داده نشد؛ ستون‌ها به ترتیب نام شرکت، نوع کالا، تامین/ساخت، گروه، شماره تماس خوانده شد.")
                }
                Prefs.setLastUpdate(this, System.currentTimeMillis())
                Prefs.setLastFile(this, name)
                runOnUiThread {
                    setBusy(false)
                    refreshStats()
                    show("بروزرسانی انجام شد", msg.toString())
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    show("خطا در خواندن فایل", e.message ?: "خطای نامشخص")
                }
            }
        }.start()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("حذف همه اطلاعات")
            .setMessage("همه شرکت‌ها و کالاهای ثبت‌شده پاک می‌شود. ادامه می‌دهید؟")
            .setPositiveButton("حذف") { _, _ ->
                Thread {
                    Db(this).clear()
                    Prefs.setLastUpdate(this, 0L)
                    Prefs.setLastFile(this, "")
                    runOnUiThread { refreshStats() }
                }.start()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun show(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("باشه", null)
            .show()
    }
}
