package ir.manabe.bank

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** ذخیره‌ی ماندگار اطلاعات با SQLite داخلی اندروید */
class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "manabe.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE records (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "company TEXT NOT NULL, goods TEXT, kind TEXT, grp TEXT, phone TEXT," +
                "email TEXT, contact TEXT, rep TEXT)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // ساختار جدول عوض شده؛ اطلاعات را دوباره از اکسل وارد کنید
        db.execSQL("DROP TABLE IF EXISTS records")
        onCreate(db)
    }

    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM records", null).use {
        if (it.moveToFirst()) it.getInt(0) else 0
    }

    fun companyCount(): Int =
        readableDatabase.rawQuery("SELECT COUNT(DISTINCT company) FROM records", null).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }

    fun all(): List<Rec> {
        val list = ArrayList<Rec>()
        readableDatabase.rawQuery(
            "SELECT company, goods, kind, grp, phone, email, contact, rep FROM records ORDER BY id",
            null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(
                    Rec(
                        c.getString(0) ?: "", c.getString(1) ?: "", c.getString(2) ?: "",
                        c.getString(3) ?: "", c.getString(4) ?: "", c.getString(5) ?: "",
                        c.getString(6) ?: "", c.getString(7) ?: ""
                    )
                )
            }
        }
        return list
    }

    fun clear() {
        writableDatabase.execSQL("DELETE FROM records")
    }

    /** جایگزینی کامل؛ تعداد ردیف‌های ثبت‌شده را برمی‌گرداند */
    fun replaceAll(list: List<Rec>): Int {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM records")
            val n = insertAll(db, list)
            db.setTransactionSuccessful()
            return n
        } finally {
            db.endTransaction()
        }
    }

    /** افزودن بدون تکرار؛ (تعداد افزوده‌شده، تعداد تکراری) */
    fun append(list: List<Rec>): Pair<Int, Int> {
        val seen = HashSet<String>()
        for (r in all()) seen.add(key(r))
        val fresh = ArrayList<Rec>()
        var dup = 0
        for (r in list) {
            if (seen.add(key(r))) fresh.add(r) else dup++
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val n = insertAll(db, fresh)
            db.setTransactionSuccessful()
            return Pair(n, dup)
        } finally {
            db.endTransaction()
        }
    }

    private fun key(r: Rec) =
        listOf(r.company, r.goods, r.kind, r.group, r.phone, r.email, r.contact, r.rep)
            .joinToString("|") { Fa.norm(it) }

    private fun insertAll(db: SQLiteDatabase, list: List<Rec>): Int {
        val st = db.compileStatement(
            "INSERT INTO records (company, goods, kind, grp, phone, email, contact, rep) " +
                "VALUES (?,?,?,?,?,?,?,?)"
        )
        var n = 0
        try {
            for (r in list) {
                st.clearBindings()
                st.bindString(1, r.company)
                st.bindString(2, r.goods)
                st.bindString(3, r.kind)
                st.bindString(4, r.group)
                st.bindString(5, r.phone)
                st.bindString(6, r.email)
                st.bindString(7, r.contact)
                st.bindString(8, r.rep)
                st.executeInsert()
                n++
            }
        } finally {
            st.close()
        }
        return n
    }
}
