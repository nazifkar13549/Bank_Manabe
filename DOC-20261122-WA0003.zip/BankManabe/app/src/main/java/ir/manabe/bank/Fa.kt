package ir.manabe.bank

/** ابزارهای متن فارسی: نرمال‌سازی برای جستجو و تبدیل ارقام */
object Fa {
    private val WS = Regex("\\s+")

    /** یکسان‌سازی ی/ک عربی، حذف نیم‌فاصله و اعراب، تبدیل ارقام به لاتین */
    fun norm(s: String?): String {
        if (s.isNullOrEmpty()) return ""
        val sb = StringBuilder(s.length)
        for (ch in s) {
            when (ch) {
                'ي', 'ى', 'ئ' -> sb.append('ی')
                'ك' -> sb.append('ک')
                'أ', 'إ', 'آ' -> sb.append('ا')
                'ؤ' -> sb.append('و')
                'ة' -> sb.append('ه')
                '‌', '‍', '‎', '‏', 'ـ' -> {}
                ' ', '\t', '\n', '\r' -> sb.append(' ')
                in 'ً'..'ٟ' -> {}
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                else -> sb.append(ch.lowercaseChar())
            }
        }
        return sb.toString().trim().replace(WS, " ")
    }

    fun digitsEn(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '۰'..'۹' -> '0' + (ch - '۰')
                    in '٠'..'٩' -> '0' + (ch - '٠')
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    fun digitsFa(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            sb.append(if (ch in '0'..'9') '۰' + (ch - '0') else ch)
        }
        return sb.toString()
    }

    fun digitsFa(n: Int): String = digitsFa(n.toString())
}
