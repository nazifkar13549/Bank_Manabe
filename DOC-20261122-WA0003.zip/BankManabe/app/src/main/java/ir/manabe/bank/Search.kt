package ir.manabe.bank

import java.text.Collator
import java.util.Locale

object Search {
    /** ترتیب باید با لیست کشویی یکی باشد */
    val FIELDS = arrayOf(
        "همه موارد",            // 0
        "نام شرکت",             // 1
        "کالا / نوع کالا",      // 2
        "تامین / ساخت",         // 3
        "گروه طبقه‌بندی",       // 4
        "شماره تماس"            // 5
    )

    /**
     * جستجو در فیلد انتخاب‌شده. نتیجه همیشه فهرست شرکت‌هاست؛
     * هر شرکت با کالا/گروه‌های منطبق نمایش داده می‌شود.
     */
    fun run(entries: List<Entry>, field: Int, query: String): List<CompanyResult> {
        val q = Fa.norm(query)
        val tokens = if (q.isEmpty()) emptyList() else q.split(' ')
        val phoneQ = q.filter { it.isDigit() }

        val groups = LinkedHashMap<String, MutableList<Entry>>()
        for (e in entries) {
            val ok = when {
                q.isEmpty() -> true
                field == 5 -> phoneQ.isNotEmpty() && e.nPhone.contains(phoneQ)
                else -> {
                    val text = when (field) {
                        1 -> e.nCompany
                        2 -> e.nGoods
                        3 -> e.nKind
                        4 -> e.nGroup
                        else -> e.nAll
                    }
                    tokens.all { text.contains(it) }
                }
            }
            if (ok) groups.getOrPut(e.nCompany) { ArrayList() }.add(e)
        }

        val result = ArrayList<CompanyResult>(groups.size)
        for ((_, list) in groups) {
            val phones = list.map { Fa.digitsEn(it.rec.phone).trim() }
                .filter { it.isNotEmpty() }
                .distinct()
            val emails = list.map { it.rec.email.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
            val contacts = list.flatMap { listOf(it.rec.contact, it.rec.rep) }
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
            val items = list.map { it.rec }
                .distinctBy { Triple(it.goods, it.kind, it.group) }
            result.add(CompanyResult(list[0].rec.company, phones, emails, contacts, items))
        }
        val collator = Collator.getInstance(Locale.forLanguageTag("fa"))
        result.sortWith { a, b -> collator.compare(a.name, b.name) }
        return result
    }
}
