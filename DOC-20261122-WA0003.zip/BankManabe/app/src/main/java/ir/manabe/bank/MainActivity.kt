package ir.manabe.bank

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var db: Db
    private lateinit var spField: Spinner
    private lateinit var etQuery: EditText
    private lateinit var tvCount: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var adapter: ResultAdapter

    private var entries: List<Entry> = emptyList()
    private val handler = Handler(Looper.getMainLooper())

    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000))
        }
    }
    private val searchTask = Runnable { doSearch() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = Db(this)
        spField = findViewById(R.id.spField)
        etQuery = findViewById(R.id.etQuery)
        tvCount = findViewById(R.id.tvCount)
        tvDate = findViewById(R.id.tvDate)
        tvTime = findViewById(R.id.tvTime)
        tvEmpty = findViewById(R.id.tvEmpty)
        val lv = findViewById<ListView>(R.id.lvResults)

        spField.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, Search.FIELDS
        )
        spField.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = doSearch()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        etQuery.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                handler.removeCallbacks(searchTask)
                handler.postDelayed(searchTask, 200)
            }
        })
        etQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(etQuery.windowToken, 0)
                true
            } else false
        }

        adapter = ResultAdapter(this, { phone -> callPhone(phone) }, { mail -> sendMail(mail) })
        lv.adapter = adapter
        lv.emptyView = tvEmpty
    }

    override fun onResume() {
        super.onResume()
        handler.post(clockTick)
        loadData()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockTick)
        handler.removeCallbacks(searchTask)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, getString(R.string.settings))
            .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun updateClock() {
        val now = System.currentTimeMillis()
        val tz = Prefs.timeZone(this)
        tvDate.text = Jalali.dateText(now, tz)
        tvTime.text = Jalali.timeText(now, tz)
    }

    private fun loadData() {
        Thread {
            val list = Db(this).all().map { Entry(it) }
            runOnUiThread {
                entries = list
                doSearch()
            }
        }.start()
    }

    private fun doSearch() {
        val results = Search.run(entries, spField.selectedItemPosition, etQuery.text.toString())
        adapter.submit(results)
        if (entries.isEmpty()) {
            tvCount.text = "اطلاعاتی ثبت نشده است"
            tvEmpty.text = "بانک اطلاعات خالی است.\nاز منوی «تنظیمات» فایل اکسل را وارد کنید."
        } else {
            tvCount.text = "${Fa.digitsFa(results.size)} شرکت یافت شد"
            tvEmpty.text = "نتیجه‌ای یافت نشد."
        }
    }

    /** شماره را می‌گیرد؛ اگر چند شماره در یک خانه باشد، انتخاب می‌دهد */
    private fun callPhone(raw: String) {
        val nums = extractNumbers(raw)
        when {
            nums.isEmpty() -> Toast.makeText(this, "شماره‌ی معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
            nums.size == 1 -> dial(nums[0])
            else -> AlertDialog.Builder(this)
                .setTitle("تماس با کدام شماره؟")
                .setItems(nums.toTypedArray()) { _, which -> dial(nums[which]) }
                .show()
        }
    }

    /**
     * شماره‌ها را از متن آزاد جدا می‌کند. نمونه‌ها:
     *  «52262141-42و52263033» ← 52262141 ، 52262142 ، 52263033
     *  «021-88776655» ← 02188776655
     *  «خانم الف 09123456789» ← 09123456789
     */
    private fun extractNumbers(raw: String): List<String> {
        val out = ArrayList<String>()
        for (part in Fa.digitsEn(raw).split(Regex("[،,;/\\n]|\\s+[-–]\\s+|و"))) {
            val pieces = part.split('-')
                .map { p -> p.filter { it.isDigit() || it == '+' } }
                .filter { it.isNotEmpty() }
            if (pieces.isEmpty()) continue
            if (pieces.size == 1 || pieces[0].length <= 4) {
                out.add(pieces.joinToString(""))
            } else {
                val first = pieces[0]
                out.add(first)
                for (p in pieces.drop(1)) {
                    out.add(if (p.length < first.length) first.dropLast(p.length) + p else p)
                }
            }
        }
        return out.filter { it.length >= 5 }.distinct()
    }

    private fun sendMail(text: String) {
        val m = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").find(text)
        if (m == null) {
            Toast.makeText(this, "ایمیل معتبری پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${m.value}")))
        } catch (e: Exception) {
            Toast.makeText(this, "برنامه‌ی ایمیل پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dial(number: String) {
        try {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        } catch (e: Exception) {
            Toast.makeText(this, "برنامه‌ی تماس پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }
}
