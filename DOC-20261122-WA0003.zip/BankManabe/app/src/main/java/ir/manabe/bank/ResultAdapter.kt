package ir.manabe.bank

import android.content.Context
import android.graphics.Paint
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView

class ResultAdapter(
    private val ctx: Context,
    private val onPhone: (String) -> Unit,
    private val onEmail: (String) -> Unit
) : BaseAdapter() {

    private var data: List<CompanyResult> = emptyList()

    fun submit(list: List<CompanyResult>) {
        data = list
        notifyDataSetChanged()
    }

    private fun dp(n: Int) = (n * ctx.resources.displayMetrics.density).toInt()

    override fun getCount() = data.size
    override fun getItem(position: Int) = data[position]
    override fun getItemId(position: Int) = position.toLong()

    private fun link(text: String, onClick: () -> Unit) = TextView(ctx).apply {
        this.text = text
        textSize = 15f
        setTextColor(0xFF1565C0.toInt())
        paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
        setPadding(0, dp(6), 0, dp(6))
        setOnClickListener { onClick() }
    }

    private fun line(text: String, collapsible: Boolean = false) = TextView(ctx).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFF37474F.toInt())
        setPadding(0, dp(3), 0, dp(3))
        if (collapsible) {
            // متن‌های طولانی (مثل فهرست کالاها) با لمس باز و بسته می‌شوند
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            setOnClickListener {
                if (maxLines == 4) {
                    maxLines = Int.MAX_VALUE
                    ellipsize = null
                } else {
                    maxLines = 4
                    ellipsize = TextUtils.TruncateAt.END
                }
            }
        }
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(ctx).inflate(R.layout.item_company, parent, false)
        val c = data[position]

        v.findViewById<TextView>(R.id.tvName).text = c.name

        val llContacts = v.findViewById<LinearLayout>(R.id.llPhones)
        llContacts.removeAllViews()
        for (ph in c.phones) {
            llContacts.addView(link("📞  $ph") { onPhone(ph) })
        }
        for (em in c.emails) {
            llContacts.addView(link("✉  $em") { onEmail(em) })
        }
        for (ct in c.contacts) {
            val hasNumber = Fa.digitsEn(ct).count { it.isDigit() } >= 7
            if (hasNumber) {
                llContacts.addView(link("👤  $ct") { onPhone(ct) })
            } else {
                llContacts.addView(line("👤  $ct"))
            }
        }

        val llItems = v.findViewById<LinearLayout>(R.id.llItems)
        llItems.removeAllViews()
        for (r in c.items) {
            if (r.goods.isBlank() && r.kind.isBlank() && r.group.isBlank()) continue
            if (llItems.childCount > 0) {
                llItems.addView(View(ctx).apply {
                    setBackgroundColor(0xFFE0E7E5.toInt())
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(1)
                    ).apply { topMargin = dp(6); bottomMargin = dp(6) }
                })
            }
            if (r.goods.isNotBlank()) llItems.addView(line("کالا: ${r.goods}", collapsible = true))
            if (r.kind.isNotBlank()) llItems.addView(line("نوع تامین: ${r.kind}"))
            if (r.group.isNotBlank()) llItems.addView(line("گروه: ${r.group}", collapsible = true))
        }
        return v
    }
}
