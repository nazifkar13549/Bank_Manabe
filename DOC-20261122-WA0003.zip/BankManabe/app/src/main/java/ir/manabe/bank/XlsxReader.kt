package ir.manabe.bank

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.math.BigDecimal
import java.util.zip.ZipInputStream

/**
 * خواندن فایل xlsx بدون هیچ کتابخانه‌ی خارجی
 * (xlsx در واقع یک zip حاوی فایل‌های XML است).
 * فقط برگه‌ی اول خوانده می‌شود.
 */
object XlsxReader {

    fun read(bytes: ByteArray): List<List<String>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val n = e.name
                if (!e.isDirectory && (
                        n == "xl/sharedStrings.xml" ||
                            n == "xl/workbook.xml" ||
                            n == "xl/_rels/workbook.xml.rels" ||
                            (n.startsWith("xl/worksheets/") && n.endsWith(".xml"))
                        )
                ) {
                    files[n] = zis.readBytes()
                }
                e = zis.nextEntry
            }
        }
        val sheetPath = findFirstSheet(files)
            ?: throw IllegalArgumentException("فایل اکسل معتبر نیست (برگه‌ای پیدا نشد).")
        val shared = files["xl/sharedStrings.xml"]?.let { parseShared(it) } ?: emptyList()
        return parseSheet(files[sheetPath]!!, shared)
    }

    private fun parser(bytes: ByteArray): XmlPullParser =
        Xml.newPullParser().apply { setInput(ByteArrayInputStream(bytes), null) }

    private fun findFirstSheet(files: Map<String, ByteArray>): String? {
        try {
            val wb = files["xl/workbook.xml"]
            val rels = files["xl/_rels/workbook.xml.rels"]
            if (wb != null && rels != null) {
                var rid: String? = null
                val p = parser(wb)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT && rid == null) {
                    if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                        for (i in 0 until p.attributeCount) {
                            if (p.getAttributeName(i).endsWith(":id")) rid = p.getAttributeValue(i)
                        }
                    }
                    ev = p.next()
                }
                if (rid != null) {
                    var target: String? = null
                    val r = parser(rels)
                    var ev2 = r.eventType
                    while (ev2 != XmlPullParser.END_DOCUMENT && target == null) {
                        if (ev2 == XmlPullParser.START_TAG && r.name == "Relationship" &&
                            r.getAttributeValue(null, "Id") == rid
                        ) {
                            target = r.getAttributeValue(null, "Target")
                        }
                        ev2 = r.next()
                    }
                    if (target != null) {
                        val path = if (target.startsWith("/")) target.substring(1) else "xl/$target"
                        if (files.containsKey(path)) return path
                    }
                }
            }
        } catch (e: Exception) {
            // به روش جایگزین می‌رویم
        }
        return files.keys
            .filter { it.startsWith("xl/worksheets/sheet") }
            .sortedWith(compareBy({ it.length }, { it }))
            .firstOrNull()
    }

    private fun parseShared(bytes: ByteArray): List<String> {
        val list = ArrayList<String>()
        val p = parser(bytes)
        val sb = StringBuilder()
        var inSi = false
        var inT = false
        var inPhonetic = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> { sb.setLength(0); inSi = true }
                    "rPh" -> inPhonetic = true
                    "t" -> inT = inSi
                }
                XmlPullParser.TEXT -> if (inT && !inPhonetic) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "rPh" -> inPhonetic = false
                    "si" -> { list.add(sb.toString()); inSi = false }
                }
            }
            ev = p.next()
        }
        return list
    }

    private fun parseSheet(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = parser(bytes)
        var rowMap = HashMap<Int, String>()
        var maxCol = -1
        var col = -1
        var type: String? = null
        val sb = StringBuilder()
        var inV = false
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> { rowMap = HashMap(); maxCol = -1; col = -1 }
                    "c" -> {
                        val ref = p.getAttributeValue(null, "r")
                        col = if (ref != null) colIndex(ref) else col + 1
                        type = p.getAttributeValue(null, "t")
                        sb.setLength(0)
                    }
                    "v" -> inV = true
                    "t" -> inT = true
                }
                XmlPullParser.TEXT -> if (inV || inT) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val raw = sb.toString()
                        val value = when (type) {
                            "s" -> shared.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: ""
                            "inlineStr", "str" -> raw
                            "b" -> if (raw.trim() == "1") "TRUE" else "FALSE"
                            else -> numberText(raw)
                        }
                        if (col >= 0) {
                            rowMap[col] = value
                            if (col > maxCol) maxCol = col
                        }
                    }
                    "row" -> if (maxCol >= 0) {
                        val m = rowMap
                        rows.add(List(maxCol + 1) { m[it] ?: "" })
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }

    /** A→0، B→1، … AA→26 */
    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch.isLetter()) n = n * 26 + (ch.uppercaseChar() - 'A' + 1) else break
        }
        return n - 1
    }

    /** اعداد (مثل شماره تلفن) بدون نمایش علمی مثل 9.12E9 */
    private fun numberText(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return ""
        return try {
            val bd = BigDecimal(t)
            val st = bd.stripTrailingZeros()
            if (st.scale() <= 0) st.toPlainString() else bd.toPlainString()
        } catch (e: NumberFormatException) {
            t
        }
    }
}
