package ir.manabe.bank

import android.content.Context
import android.net.Uri
import java.io.IOException

/** تبدیل فایل اکسل/CSV انتخاب‌شده به فهرست رکوردها */
object Importer {

    class Result(val rows: List<Rec>, val skipped: Int, val headerFound: Boolean)

    // اندیس فیلدها
    private const val F_COMPANY = 0
    private const val F_GOODS = 1
    private const val F_KIND = 2
    private const val F_GROUP = 3
    private const val F_PHONE = 4
    private const val F_EMAIL = 5
    private const val F_CONTACT = 6
    private const val F_REP = 7
    private const val FIELD_COUNT = 8

    private val WS = Regex("\\s+")

    fun parse(ctx: Context, uri: Uri): Result {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("فایل قابل خواندن نیست.")
        if (bytes.isEmpty()) throw IllegalArgumentException("فایل خالی است.")

        val table: List<List<String>> = when {
            bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte() ->
                XlsxReader.read(bytes)
            bytes.size >= 4 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte() ->
                throw IllegalArgumentException(
                    "این فایل با فرمت قدیمی xls است.\nآن را در اکسل با Save As به فرمت xlsx ذخیره کنید و دوباره امتحان کنید."
                )
            else -> CsvReader.parse(bytes)
        }
        return toRecords(table)
    }

    /** از روی عنوان ستون‌ها تشخیص می‌دهد کدام ستون چیست */
    private fun detectHeader(row: List<String>): IntArray {
        val map = IntArray(FIELD_COUNT) { -1 }
        for ((i, cell) in row.withIndex()) {
            val h = Fa.norm(cell)
            if (h.isEmpty()) continue
            val f = when {
                h.contains("ایمیل") || h.contains("email") || h.contains("پست الکترونیک") -> F_EMAIL
                h.contains("تامین") || h.contains("ساخت") -> F_KIND
                h.contains("گروه") || h.contains("طبقه") -> F_GROUP
                h.contains("نماینده") -> F_REP
                h.contains("رابط") -> F_CONTACT
                h.contains("تلفن") || h.contains("تماس") || h.contains("موبایل") ||
                    h.contains("همراه") || h.contains("شماره") -> F_PHONE
                h.contains("کالا") || h.contains("محصول") || h.contains("نوع") -> F_GOODS
                h.contains("شرکت") || h.contains("فروشگاه") || h.contains("نام") -> F_COMPANY
                else -> -1
            }
            if (f >= 0 && map[f] == -1) map[f] = i
        }
        return map
    }

    private fun toRecords(table: List<List<String>>): Result {
        if (table.isEmpty()) return Result(emptyList(), 0, false)

        var map = detectHeader(table[0])
        val headerFound = map[F_COMPANY] >= 0 && map.count { it >= 0 } >= 2
        var startRow = 1
        if (!headerFound) {
            // بدون عنوان: نام شرکت، کالا، تامین/ساخت، گروه، تلفن
            map = IntArray(FIELD_COUNT) { if (it <= F_PHONE) it else -1 }
            startRow = 0
        }

        val out = ArrayList<Rec>()
        var skipped = 0
        for (r in startRow until table.size) {
            val row = table[r]
            if (row.all { it.isBlank() }) continue
            fun cell(f: Int): String {
                val idx = map[f]
                return if (idx >= 0) clean(row.getOrNull(idx) ?: "") else ""
            }
            val company = cell(F_COMPANY)
            if (company.isEmpty()) {
                skipped++
                continue
            }
            out.add(
                Rec(
                    company, cell(F_GOODS), cell(F_KIND), cell(F_GROUP),
                    fixPhone(cell(F_PHONE)), cell(F_EMAIL), cell(F_CONTACT), cell(F_REP)
                )
            )
        }
        return Result(out, skipped, headerFound)
    }

    /** حذف کاراکترهای زائد اکسل، فاصله‌های اضافه و علامت‌های خالی مثل -- */
    private fun clean(s: String): String {
        val t = s.replace("_x000D_", " ").replace(' ', ' ').replace(WS, " ").trim()
        return if (t.isNotEmpty() && t.all { it == '-' || it == '–' || it == '—' || it == '_' }) "" else t
    }

    /** ارقام فارسی→لاتین؛ اگر صفر ابتدایی در اکسل افتاده باشد (۱۰ رقم) اضافه می‌شود */
    private fun fixPhone(s: String): String {
        val d = Fa.digitsEn(s).trim()
        return if (d.length == 10 && d.all { it.isDigit() }) "0$d" else d
    }
}
