package ir.manabe.bank

/** یک ردیف از فایل اکسل */
data class Rec(
    val company: String,        // نام شرکت / فروشگاه
    val goods: String,          // کالاها
    val kind: String,           // نوع تامین (تامین‌کننده، تولیدکننده، ...)
    val group: String,          // گروه‌های طبقه‌بندی
    val phone: String,          // تلفن
    val email: String = "",     // ایمیل
    val contact: String = "",   // رابط
    val rep: String = ""        // نام نماینده
)

/** ردیف همراه با نسخه‌ی نرمال‌شده برای جستجوی سریع */
class Entry(val rec: Rec) {
    val nCompany = Fa.norm(rec.company)
    val nGoods = Fa.norm(rec.goods)
    val nKind = Fa.norm(rec.kind)
    val nGroup = Fa.norm(rec.group)

    // فقط رقم‌ها (تلفن و شماره‌های داخل ستون رابط)، جدا شده با | تا شماره‌ها به هم نچسبند
    val nPhone = digitsOnly(rec.phone) + "|" + digitsOnly(rec.contact)

    val nAll = listOf(
        nCompany, nGoods, nKind, nGroup, Fa.norm(rec.phone),
        Fa.norm(rec.email), Fa.norm(rec.contact), Fa.norm(rec.rep)
    ).joinToString(" ")

    private fun digitsOnly(s: String) = Fa.digitsEn(s).filter { it.isDigit() }
}

/** نتیجه‌ی جستجو: یک شرکت و موارد منطبق آن */
class CompanyResult(
    val name: String,
    val phones: List<String>,
    val emails: List<String>,
    val contacts: List<String>,
    val items: List<Rec>
)
