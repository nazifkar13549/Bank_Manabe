package ir.manabe.bank

import android.content.Context
import java.util.TimeZone

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("manabe_prefs", Context.MODE_PRIVATE)

    fun tehranTz(c: Context): Boolean = sp(c).getBoolean("tehran_tz", true)
    fun setTehranTz(c: Context, v: Boolean) = sp(c).edit().putBoolean("tehran_tz", v).apply()

    fun replaceMode(c: Context): Boolean = sp(c).getBoolean("replace_mode", true)
    fun setReplaceMode(c: Context, v: Boolean) = sp(c).edit().putBoolean("replace_mode", v).apply()

    fun lastUpdate(c: Context): Long = sp(c).getLong("last_update", 0L)
    fun setLastUpdate(c: Context, v: Long) = sp(c).edit().putLong("last_update", v).apply()

    fun lastFile(c: Context): String = sp(c).getString("last_file", "") ?: ""
    fun setLastFile(c: Context, v: String) = sp(c).edit().putString("last_file", v).apply()

    fun timeZone(c: Context): TimeZone =
        if (tehranTz(c)) TimeZone.getTimeZone("Asia/Tehran") else TimeZone.getDefault()
}
